<p id="copyright">&copy; 2010 25 HERZ</p><p id="mailto">По вопросам и предложениям - <a href="mailto:rip4eg@gmail.com">rip4eg@gmail.com</a></p>
